<template>
    <view>
        <view class="name">
            {{activity.name}}
        </view>
        <view class="content">
            <rich-text :nodes="activity.content"></rich-text>
        </view>
        <button @click="toSignUp(activity.templateId)" class="submit-btn cu-btn block bg-blue lg round" v-if="activity.templateId">点击报名</button>
    </view>
</template>

<script>
import { getActivity } from '@/api/activity/activity.js'
export default {
    data() {
        return {
            activity: {
                name: '',
                content: '',
                templateId: ''
            }
        }
    },
    methods: {
        toSignUp(id) {
            if (!id) {
                return
            }
            this.$tab.navigateTo('/pages/work/index?id=' + id)
        }
    },
    created() {
        const id = this.$route.query.id
        getActivity(id).then(res => {
            this.activity = res.data
        })
    }
}
</script>
<style lang="scss">
page {
    background:
        radial-gradient(#51c4c750 5px, transparent 5px),
        radial-gradient(#51c4c720 5px, transparent 5px),
        linear-gradient(#f5f6f7 3px, transparent 0),
        linear-gradient(45deg, transparent 74px, transparent 75px, #51c4c730 75px, #51c4c730 76px, transparent 77px, transparent 109px),
        linear-gradient(-45deg, transparent 75px, transparent 76px, #51c4c730 76px, #51c4c730 77px, transparent 78px, transparent 109px),
        #f5f6f7;
        background-size: 109px 109px, 109px 109px,100% 6px, 109px 109px, 109px 109px;
        background-position: 54px 55px, 0px 0px, 0px 0px, 0px 0px, 0px 0px;
    padding-bottom: 50rpx;
}
.name {
    text-align: center;
    font-size:45rpx;
    color: #51c4c7;
    font-weight: bold;
    margin-top: 20px;
    margin-bottom: 20px;
}
.content {
    width: 690rpx;
    margin: 0 auto;
    padding: 20rpx;
    border: #51c4c790 solid 5rpx;
    border-radius: 30rpx;
    box-shadow: 4rpx 4rpx 4rpx 4rpx #33333330;
    background-color: #ffffff;
}
.submit-btn {
    margin: 0 30rpx;
    margin-top: 50rpx;
    height: 80rpx;
    background-color: #51c4c7;
}
</style>