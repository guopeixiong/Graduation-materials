<template>
    
</template>

<script>
    export default {
        data() {
            return {
                
            }
        },
        methods: {
            
        },
        created() {
            
        }
    }
</script>

<style>
</style>