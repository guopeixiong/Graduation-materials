import request from '@/utils/request'

// 查询活动详情
export function getActivity(id) {
    return request({
      url: '/h5/activity?id=' + id,
      method: 'get'
    })
}