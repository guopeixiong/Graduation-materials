package com.ruanchuang.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruanchuang.domain.CommonQaInfo;

/**
 * @author guopx
 * @since 2023/11/30
 */
public interface CommonQaInfoMapper extends BaseMapper<CommonQaInfo> {
}
