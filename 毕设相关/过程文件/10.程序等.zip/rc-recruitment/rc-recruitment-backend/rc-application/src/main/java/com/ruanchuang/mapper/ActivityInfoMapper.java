package com.ruanchuang.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruanchuang.domain.ActivityInfo;

/**
 * @Author guopeixiong
 * @Date 2024/3/16
 * @Email peixiongguo@163.com
 */
public interface ActivityInfoMapper extends BaseMapper<ActivityInfo> {
}
