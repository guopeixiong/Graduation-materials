package com.ruanchuang.mapper;

import com.ruanchuang.domain.IndexRollingImage;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 首页轮播图管理表 Mapper 接口
 * </p>
 *
 * @author guopeixiong
 * @since 2023-08-01
 */
public interface IndexRollingImageMapper extends BaseMapper<IndexRollingImage> {

}
