package com.ruanchuang.controller.admin;

import com.ruanchuang.annotation.Log;
import com.ruanchuang.annotation.RepeatSubmit;
import com.ruanchuang.domain.dto.AddAdminDto;
import com.ruanchuang.domain.dto.UpdateUserInfoDto;
import com.ruanchuang.domain.dto.UserQueryDto;
import com.ruanchuang.domain.dto.UserStatusDto;
import com.ruanchuang.enums.BusinessType;
import com.ruanchuang.enums.Constants;
import com.ruanchuang.model.CommonResult;
import com.ruanchuang.service.SysUserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * @Author guopeixiong
 * @Date 2023/12/23
 * @Email peixiongguo@163.com
 */
@Api(tags = "用户管理相关接口")
@RestController
@RequestMapping("/admin/user")
public class UserInfoManageController {

    @Autowired
    private SysUserService sysUserService;

    @ApiOperation("分页查询普通用户")
    @GetMapping("/normal/list")
    public CommonResult normalList(@Validated UserQueryDto userQueryDto) {
        return CommonResult.ok(sysUserService.normalList(userQueryDto));
    }

    @ApiOperation("禁用普通用户")
    @Log(type = Constants.LOG_TYPE_ADMIN, title = "修改用户账号状态", businessType = BusinessType.UPDATE, saveRequestParam = true)
    @PutMapping("/normal/status")
    public CommonResult normalDisAble(@RequestBody UserStatusDto userStatusDto) {
        sysUserService.updateUserStatus(userStatusDto);
        return CommonResult.ok();
    }

    @ApiOperation("分页查询管理员用户")
    @GetMapping("/admin/list")
    public CommonResult adminList(@Validated UserQueryDto userQueryDto) {
        return CommonResult.ok(sysUserService.adminList(userQueryDto));
    }

    @ApiOperation("新增管理员")
    @RepeatSubmit
    @Log(type = Constants.LOG_TYPE_ADMIN, title = "新增管理员", businessType = BusinessType.INSERT, saveRequestParam = true, saveResponseResult = true)
    @PostMapping("/admin/add")
    public CommonResult addAdmin(@Validated @RequestBody AddAdminDto addAdminDto) {
        sysUserService.addAdmin(addAdminDto);
        return CommonResult.ok();
    }

    @ApiOperation("管理员修改个人信息")
    @RepeatSubmit
    @Log(type = Constants.LOG_TYPE_ADMIN, title = "管理员修改个人信息", businessType = BusinessType.UPDATE)
    @PutMapping("/admin/update")
    public CommonResult updateMyInfo(@Validated @RequestBody UpdateUserInfoDto infoDto) {
        sysUserService.updateAdminInfo(infoDto);
        return CommonResult.ok();
    }

    @ApiOperation("管理员修改账户密码")
    @RepeatSubmit
    @Log(type = Constants.LOG_TYPE_ADMIN, title = "管理员修改账户密码", businessType = BusinessType.UPDATE)
    @PutMapping("/admin/update/password")
    public CommonResult updateMyPassword(@RequestBody String pwd) {
        sysUserService.updateAdminPassword(pwd);
        return CommonResult.ok();
    }

    @ApiOperation("修改管理员类型")
    @RepeatSubmit
    @Log(type = Constants.LOG_TYPE_ADMIN, title = "修改管理员类型", businessType = BusinessType.UPDATE)
    @PutMapping("/admin/adminType/{id}/{type}")
    public CommonResult updateAdminType(@PathVariable("id") Long id, @PathVariable("type") Integer type) {
        sysUserService.updateAdminType(id, type);
        return CommonResult.ok();
    }

}
