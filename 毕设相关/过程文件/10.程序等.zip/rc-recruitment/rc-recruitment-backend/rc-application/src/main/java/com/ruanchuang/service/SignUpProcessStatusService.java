package com.ruanchuang.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ruanchuang.domain.SignUpProcessStatus;

/**
 * @author guopx
 * @since 2023/12/4
 */
public interface SignUpProcessStatusService extends IService<SignUpProcessStatus> {
}
