package com.ruanchuang.mapper;

import com.ruanchuang.domain.SignUpFormQuestion;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 报名表问题表 Mapper 接口
 * </p>
 *
 * @author guopeixiong
 * @since 2023-08-01
 */
public interface SignUpFormQuestionMapper extends BaseMapper<SignUpFormQuestion> {

}
