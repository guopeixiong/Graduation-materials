package com.ruanchuang.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruanchuang.domain.SignUpProcess;

/**
 * @author guopx
 * @since 2023/12/4
 */
public interface SignUpProcessMapper extends BaseMapper<SignUpProcess> {
}
